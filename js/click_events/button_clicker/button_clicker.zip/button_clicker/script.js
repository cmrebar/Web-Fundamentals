function logout (element) {
    if (element.innerHTML = "Login") {
        element.innerHTML = "Logout";
        console.log("logout")
    };
    
}
