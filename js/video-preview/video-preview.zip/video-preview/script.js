console.log("page loaded...");
document.getElementById('vid').controls = true;
